# IBM Applied Data Science Capstone — SpaceX Falcon 9 Landing Prediction

Predicting whether the Falcon 9 first stage lands successfully, so a competing launch provider can estimate the true cost of a SpaceX launch.

**Author:** Kautzar

## Notebooks

| # | Notebook | What it does |
|---|----------|--------------|
| 1 | [1_spacex_data_collection_api.ipynb](1_spacex_data_collection_api.ipynb) | Collects launch data from the SpaceX REST API, keeps Falcon 9 launches, fills missing payload mass |
| 2 | [2_webscraping_falcon9.ipynb](2_webscraping_falcon9.ipynb) | Scrapes Falcon 9 launch records from Wikipedia with BeautifulSoup |
| 3 | [3_data_wrangling.ipynb](3_data_wrangling.ipynb) | Explores sites, orbits and outcomes; creates the `Class` landing label |
| 4 | [4_eda_with_sql.ipynb](4_eda_with_sql.ipynb) | Answers 10 questions with SQL (SQLite) |
| 5 | [5_eda_dataviz.ipynb](5_eda_dataviz.ipynb) | Scatter, bar and line charts; one-hot encoding of features |
| 6 | [6_launch_site_location_folium.ipynb](6_launch_site_location_folium.ipynb) | Folium maps: launch sites, outcome clusters, proximity distances |
| 7 | [spacex_dash_app.py](spacex_dash_app.py) | Plotly Dash dashboard: site dropdown, success pie chart, payload slider, scatter |
| 8 | [8_machine_learning_prediction.ipynb](8_machine_learning_prediction.ipynb) | Logistic regression, SVM, decision tree and KNN tuned with GridSearchCV |

The final presentation is in [SpaceX_Capstone_Kautzar.pdf](SpaceX_Capstone_Kautzar.pdf).

## Key results

- 90 Falcon 9 launches (2010–2020); 66.7% of first stages landed.
- Landing success rose from 0% (2010–2013) to 90% (2019).
- KSC LC-39A has the highest site success rate (76.9%).
- All four classifiers reach 83.3% test accuracy; across 50 resampled splits SVM is the best model (84.4%).

## Running locally

```bash
pip install pandas numpy requests beautifulsoup4 matplotlib seaborn scikit-learn folium dash plotly
python spacex_dash_app.py   # dashboard at http://127.0.0.1:8050
```

Notebooks read the IBM course files and fall back to the copies in `data/` if a URL is unreachable.
